import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Parcheggio parcheggio = new Parcheggio("Parcheggio Centrale");

        while (true) {
            System.out.println("\n--- Menu Parcheggio ---");
            System.out.println("1. Aggiungere una macchina");
            System.out.println("2. Eliminare una macchina");
            System.out.println("3. Vedere le macchine nel parcheggio");
            System.out.println("4. Trovare una macchina");
            System.out.println("5. Uscire");
            System.out.print("Scegli un'opzione: ");

            int scelta = scanner.nextInt();
            scanner.nextLine(); // Consuma il newline

            switch (scelta) {
                case 1:
                    System.out.print("Inserisci targa (formato: AA123BB): ");
                    String targa = scanner.nextLine();
                    if (!parcheggio.isTargaValida(targa)) {
                        System.out.println("Targa non valida. Assicurati che sia nel formato corretto (AA123BB).");
                        break;
                    }
                    else
                    {
                        System.out.print("Inserisci marca: ");
                        String marca = scanner.nextLine();
                        System.out.print("Inserisci modello: ");
                        String modello = scanner.nextLine();
                        int numero = parcheggio.getNextAutoNumber();
                        Auto auto = new Auto(numero, targa, marca, modello);
                        parcheggio.inserisciAuto(auto);
                        System.out.println("Auto aggiunta con successo!");
                        break;
                    }
                case 2:
                    System.out.println("Macchine nel parcheggio:");
                    parcheggio.mostraLista();
                    System.out.print("Inserisci il numero della macchina da eliminare (formato: Auto#): ");
                    String input = scanner.nextLine();
                    if (input.startsWith("Auto")) {
                        try {
                            int numeroDaEliminare = Integer.parseInt(input.substring(4));
                            if (parcheggio.eliminaAuto(numeroDaEliminare)) {
                                System.out.println("Auto eliminata con successo.");
                            } else {
                                System.out.println("Nessuna auto trovata con quel numero.");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Formato non valido. Assicurati di inserire 'Auto#' con un numero valido.");
                        }
                    } else {
                        System.out.println("Formato non valido. Assicurati di inserire 'Auto#' con un numero valido.");
                    }
                    break;

                case 3:
                    System.out.println("Macchine nel parcheggio:");
                    parcheggio.mostraLista();
                    break;

                case 4:
                    System.out.print("Inserisci la targa da cercare: ");
                    String targaDaCercare = scanner.nextLine();
                    Auto cercata = parcheggio.cercaAuto(targaDaCercare);
                    if (cercata != null) {
                        System.out.println("Auto trovata: " + cercata);
                    } else {
                        System.out.println("Auto non trovata.");
                    }
                    break;

                case 5:
                    System.out.println("Uscita dal programma.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opzione non valida, riprova.");
            }
        }
    }
}