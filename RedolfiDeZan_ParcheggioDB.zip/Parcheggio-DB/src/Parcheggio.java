import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

class Parcheggio {
    private String nome;
    private List<Auto> autoList;
    private static final String TARGA_REGEX = "^[A-Z]{2}\\d{3}[A-Z]{2}$"; // Regex per la targa

    public Parcheggio(String nome) {
        this.nome = nome;
        this.autoList = new ArrayList<>();
    }

    public String getNome() {

        return nome;
    }

    public void setNome(String nome) {

        this.nome = nome;
    }

    @Override
    public String toString() {

        return "Parcheggio [Nome=" + nome + ", Auto=" + autoList + "]";
    }

    public void inserisciAuto(Auto auto) {
        autoList.add(auto);
    }

    public boolean eliminaAuto(int numero) {
        return autoList.removeIf(auto -> auto.getNumero() == numero);
    }

    public Auto cercaAuto(String targa) {
        for (Auto auto : autoList) {
            if (auto.getTarga().equals(targa)) {
                return auto;
            }
        }
        return null; // Restituisce null se non trovata
    }

    public void mostraLista() {
        if (autoList.isEmpty()) {
            System.out.println("Nessuna auto nel parcheggio.");
        } else {
            for (Auto auto : autoList) {
                System.out.println(auto);
            }
        }
    }

    public int getNextAutoNumber() {

        return autoList.size() + 1;
    }

    // Metodo per controllare se la targa è valida
    public boolean isTargaValida(String targa) {

        return Pattern.matches(TARGA_REGEX, targa);
    }
}