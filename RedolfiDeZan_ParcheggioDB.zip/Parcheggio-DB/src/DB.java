
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DB {
    private static final String URL = "jdbc:mysql://localhost:3306/your_database_name";
    private static final String USER = "your_username";
    private static final String PASSWORD = "your_password";

    // Connessione al database                                                                                                                       g
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Inserimento di una nuova auto nel database
    public static void inserisciAutoDB(Auto auto) {
        String query = "INSERT INTO auto (numero, targa, marca, modello) VALUES (?, ?, ?, ?)";

        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, auto.getNumero());
            statement.setString(2, auto.getTarga());
            statement.setString(3, auto.getMarca());
            statement.setString(4, auto.getModello());

            statement.executeUpdate();
            System.out.println("Auto inserita nel database.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Ricerca un'auto nel database per targa
    public static Auto cercaAutoDB(String targa) {
        String query = "SELECT * FROM auto WHERE targa = ?";

        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, targa);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int numero = resultSet.getInt("numero");
                String marca = resultSet.getString("marca");
                String modello = resultSet.getString("modello");
                return new Auto(numero, targa, marca, modello);
            } else {
                System.out.println("Auto non trovata nel database.");
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
